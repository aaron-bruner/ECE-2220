/* lab1.c
 * yourname <<----- CHANGE the comments and add your name
 * your username         <<-----  change to your username
 * ECE 2220, Fall 2019
 * MP1
 *
 * NOTE:  You must update all of the following comments!
 * 
 * Purpose:  A template for MP1 --   YOU MUST CHANGE THIS
 *
 * Assumptions:
 *
 * Bugs:  
 *
 * See the ECE programming guide for requirements
 *
 * Are you unhappy with the way this code is formatted?  You can easily
 * reformat (and automatically indent) your code using the astyle 
 * command.  If it is not installed use the Ubuntu Software Center to 
 * install astyle.  Then in a terminal on the command line do
 *     astyle --style=kr lab1.c
 *
 * See "man astyle" for different styles.  Replace "kr" with one of
 * ansi, java, gnu, linux to see different options.  Or, set up your
 * own style.
 *
 * To create a nicely formated PDF file for printing install the enscript 
 * command.  To create a PDF for "file.c" in landscape with 2 columns do:
 *     enscript file.c -G2rE -o - | ps2pdf - file.pdf
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//notice there is no semi-colon at the end of a #define
#define MAXLINE 100
#define MINNUM 10
#define MAXNUM 100
#define MINSIZE 6
#define MAXSIZE 12
#define MINKEY 1
#define MAXKEY 5


int main()
{
    char line[MAXLINE];
    int msgsize;
    int keyvalue;

    /* You are REQUIRED to use fgets() and sscanf().  
     * Use of scanf() is prohibited!
     */
    fgets(line, MAXLINE, stdin);
    sscanf(line, "%d", &msgsize);
    printf("\nMsgsize is set to %d.\n", msgsize);
    printf("\nKeyValue is set to %d.\n", keyvalue);




    // Use one of the following prints
    // you must use exactly these prints and you cannot change the text

    printf(">> No more message received. Program exit.\n\n\n");
    printf(">> Msg:  I'm safe, all good.\n");
    printf(">> Msg:  Mission Success. Agent ID: %d.\n", id);
    printf(">> Msg:  Mission Failed. Agent ID: %d.\n", id);
    printf(">> Msg:  Don't contact me.\n");
    printf(">> Msg:  No Content.    \n");
    // or
    printf(">> Corrupted Message.\n");
    printf("No waveform detected\n");
    printf("\n>> Agent Center is not safe now. Go find a safe place. Program exit.\n\n\n");

    exit(0);
}

